// Copyright (c) Microsoft. All rights reserved.
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Microsoft.Azure.Devices.Edge.Agent.Docker.Test")]