// Copyright (c) Microsoft. All rights reserved.

mod module;

pub use self::module::ModuleClient;
