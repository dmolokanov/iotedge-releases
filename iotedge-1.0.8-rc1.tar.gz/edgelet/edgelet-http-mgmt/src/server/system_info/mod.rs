// Copyright (c) Microsoft. All rights reserved.
mod get;

pub use self::get::GetSystemInfo;
