#ifndef HSM_ERR_H
#define HSM_ERR_H

#define __FAILURE__ MU_FAILURE

#endif //HSM_ERR_H
