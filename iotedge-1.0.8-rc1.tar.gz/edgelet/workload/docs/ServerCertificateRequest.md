# ServerCertificateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**common_name** | **String** | Subject common name | [default to null]
**expiration** | **String** | Certificate expiration date-time (ISO 8601) | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


