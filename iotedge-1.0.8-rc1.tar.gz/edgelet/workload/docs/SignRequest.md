# SignRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key_id** | **String** | Name of key to perform sign operation. | [default to null]
**algo** | **String** | Sign algorithm to be used. | [default to null]
**data** | **String** | Data to be signed. | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


