// Copyright (c) Microsoft. All rights reserved.
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Microsoft.Azure.Devices.Edge.Hub.Amqp.Test")]
