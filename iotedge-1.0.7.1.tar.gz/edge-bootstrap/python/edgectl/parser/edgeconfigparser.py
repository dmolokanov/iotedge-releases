class EdgeConfigParser(object):
    def __init__(self, args, deployment_type=None):
        self._input_args = args
        self._deployment_type = deployment_type
        return

    def parse(self, config_file_path=None):
        pass
