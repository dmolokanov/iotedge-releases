// Copyright (c) Microsoft. All rights reserved.
namespace Microsoft.Azure.Devices.Edge.Hub.Amqp.LinkHandlers
{
    public interface IReceivingLinkHandler : ILinkHandler
    {
    }
}
