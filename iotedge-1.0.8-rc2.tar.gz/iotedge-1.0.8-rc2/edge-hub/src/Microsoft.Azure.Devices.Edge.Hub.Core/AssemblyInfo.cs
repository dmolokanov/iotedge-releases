// Copyright (c) Microsoft. All rights reserved.
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Microsoft.Azure.Devices.Edge.Hub.Core.Test")]
[assembly: InternalsVisibleTo("Microsoft.Azure.Devices.Edge.Hub.Mqtt.Test")]
[assembly: InternalsVisibleTo("Microsoft.Azure.Devices.Edge.Hub.E2E.Test")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
